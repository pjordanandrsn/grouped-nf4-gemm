# Copyright (c) 2026 Cerin Amroth LLC. MIT license (see LICENSE).
"""Uniform symmetric int4 (blocksize 32) pack + decode-GEMV kernels.

The serve-lane format the sm_120 census licensed: a UNIFORM grid unpacks
arithmetically -- no codebook, no gather -- so the inner loop is integer
multiply-accumulate over int8-quantised activations, exact in int32,
with one fp32 scale product per (row, k-block). Measured on the census
cells (RTX 5090, graph-replay): dense M=1 qkv-shape 5.65 us at
1,044 GB/s -- 6.9x over the NF4 register-LUT GEMV and 2.6x over the
bf16 dense baseline; grouped top-8 expert cells 3.8-4.3x over the NF4
grouped GEMV. rel err vs an fp32 reference of the same int4 values is
~1e-7: the accumulation is exact, only output rounding remains.

This module is DECODE-ONLY (M = 1 rows). Prefill and training stay on
their existing paths: at large M dequant-then-matmul wins the fused/
dequant crossover, and NF4 remains the canonical training format (the
int4 grid costs +0.007 ppl on experts and -0.006 on attention at the
8k-token gate; the lm_head measured +0.18 and must NOT use this format).

Two measurement rules are load-bearing for anyone touching configs here
(receipts: audit int4port P1):
  - time under CUDA-graph replay, never eager -- the eager host floor
    (~28 us/call) hides everything;
  - sweep configs UNDER that metric -- eager sweeps anti-select split-K
    because the partials reduce pays a launch the replay does not.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

from int4_pack_ref import BLOCK, dequant_int4_ref, pack_int4_b32  # noqa: F401


# ------------------------------------------------- activation quantise --
@triton.jit
def _quant_x_rows(x_ptr, xq_ptr, xs_ptr, K: tl.constexpr):
    """Per-(row, 32-block) int8 symmetric quantise (Q8-style). Grid
    (R, K//32): blocks are independent, so the k loop the original
    one-program-per-row kernel carried was pure serialization -- the
    B=16 census priced it at 11.2 us/call for trivially-parallel work.
    Same arithmetic per block, so outputs are bitwise-identical."""
    # literal 32 throughout: triton JIT bodies cannot read imported
    # module globals (BLOCK lives in int4_pack_ref for the host side)
    r = tl.program_id(0)
    kb = tl.program_id(1)
    o32 = tl.arange(0, 32)
    x = tl.load(x_ptr + r * K + kb * 32 + o32).to(tl.float32)
    s = tl.max(tl.abs(x)) / 127.0 + 1e-12
    q = tl.floor(x / s + 0.5)
    q = tl.minimum(tl.maximum(q, -127.0), 127.0)
    tl.store(xq_ptr + r * K + kb * 32 + o32, q.to(tl.int8))
    tl.store(xs_ptr + r * (K // 32) + kb, s)


def quant_x_rows(x: torch.Tensor):
    """``x [R, K]`` -> ``(xq [R, K] int8, xs [R, K//32] fp32)``."""
    R, K = x.shape
    xq = torch.empty(R, K, dtype=torch.int8, device=x.device)
    xs = torch.empty(R, K // BLOCK, dtype=torch.float32, device=x.device)
    _quant_x_rows[(R, K // BLOCK)](x.contiguous(), xq, xs, K=K)
    return xq, xs


# ----------------------------------------------------------- the kernel --
@triton.jit
def _gemv_int4_b32(xq_ptr, xs_ptr, w_ptr, ws_ptr, eid_ptr, out_ptr,
                   N, K: tl.constexpr, R: tl.constexpr,
                   BLOCK_N: tl.constexpr, SK: tl.constexpr,
                   KU: tl.constexpr):
    """One program computes BLOCK_N output rows of expert ``eids[e]`` for
    activation row ``e``, over its split-K span. Grid (cdiv(N,BN), R, SK).
    Dense callers pass R=1 with ``eids=[0]``. Stores fp32 partials at
    ``out[(sk*R + e)*N + n]``; the wrapper reduces (exact in fp32 --
    the int32 block dots are exact, so only the scale sums reorder)."""
    pid = tl.program_id(0)
    e = tl.program_id(1)
    sk = tl.program_id(2)
    eid = tl.load(eid_ptr + e).to(tl.int64)
    offs_n = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    n_mask = offs_n < N
    acc = tl.zeros((BLOCK_N,), dtype=tl.float32)
    KB: tl.constexpr = K // 32
    span: tl.constexpr = (KB + SK * KU - 1) // (SK * KU)
    ku = tl.arange(0, KU)
    pair = tl.arange(0, 16)
    wbase = w_ptr + eid * N * (K // 2)
    sbase = ws_ptr + eid * N * KB
    for kbi in range(0, span):
        kb0 = (sk * span + kbi) * KU
        if kb0 < KB:
            xoff = e * K + kb0 * 32 + ku[:, None] * 32 + 2 * pair[None, :]
            xe = tl.load(xq_ptr + xoff).to(tl.int32)
            xo = tl.load(xq_ptr + xoff + 1).to(tl.int32)
            xsv = tl.load(xs_ptr + e * KB + kb0 + ku)
            wb = tl.load(wbase + offs_n[:, None] * (K // 2) + kb0 * 16
                         + tl.arange(0, KU * 16)[None, :],
                         mask=n_mask[:, None], other=0).to(tl.int32)
            wb = tl.reshape(wb, (BLOCK_N, KU, 16))
            lo = (wb & 0xF) - 8
            hi = ((wb >> 4) & 0xF) - 8
            d = tl.sum(lo * xe[None, :, :], axis=2) \
              + tl.sum(hi * xo[None, :, :], axis=2)
            ws = tl.load(sbase + offs_n[:, None] * KB + kb0 + ku[None, :],
                         mask=n_mask[:, None], other=0.0).to(tl.float32)
            acc += tl.sum(d.to(tl.float32) * (ws * xsv[None, :]), axis=1)
    tl.store(out_ptr + (sk * R + e) * N + offs_n, acc, mask=n_mask)


def _plan(N: int, K: int):
    """Config from the graph-metric sweep on sm_120 (receipts int4port):
    bn128/w4-8/sk8 class won every census cell; sk fills the grid to
    2+ waves. KU (k-blocks per loop iteration) MUST divide K//32: the
    kernel guards only the first block of each fat iteration, so a
    non-dividing KU reads past the row tail -- caught by the checkout
    parity gate at K=64/96 (garbage-scale errors), invisible on census
    shapes where 4 | K//32. Kept simple until a second box class is
    measured."""
    kb = K // 32
    ku = 4 if kb % 4 == 0 else (2 if kb % 2 == 0 else 1)
    sk = 8 if (triton.cdiv(N, 128) * 8) >= 256 else 16
    sk = min(sk, max(1, kb // ku))            # never more splits than spans
    return 128, 4, sk, ku                     # BLOCK_N, warps, SK, KU


@triton.jit
def _reduce_partials(part_ptr, out_ptr, SK: tl.constexpr, RN,
                     BLOCK: tl.constexpr):
    """``out[i] = bf16(sum_sk part[sk, i])`` over the flattened ``[R, N]``
    -- the split-K reduction and the bf16 cast in ONE launch. The
    ``part.reshape(sk, R, N).sum(0).to(bf16)`` it replaces was three
    dispatches (view, sum, copy) and two kernels per projection call --
    the largest glue site in Qwen3's B=1 op census (bo3p: 596 us of an
    eager step, 864 dispatches, all from this line)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < RN
    acc = tl.zeros((BLOCK,), dtype=tl.float32)
    for sk in tl.static_range(SK):
        acc += tl.load(part_ptr + sk * RN + offs, mask=m, other=0.0)
    tl.store(out_ptr + offs, acc.to(tl.bfloat16), mask=m)


def reduce_partials(part: torch.Tensor, sk: int, R: int, N: int,
                    out: torch.Tensor | None = None):
    """fp32 ``part [sk*R, N]`` -> bf16 ``[R, N]``, one launch. ``out`` may be
    preallocated (pass it under capture)."""
    if out is None:
        out = torch.empty(R, N, dtype=torch.bfloat16, device=part.device)
    rn = R * N
    block = 1024
    _reduce_partials[(triton.cdiv(rn, block),)](
        part, out, SK=sk, RN=rn, BLOCK=block, num_warps=4)
    return out


def gemv_int4_b32(xq, xs, packed, scales, eids, N: int, K: int,
                  part: torch.Tensor | None = None):
    """Grouped decode GEMV: ``R = eids.numel()`` activation rows, row ``e``
    against expert ``eids[e]``. ``packed [E, N, K//2]``, ``scales
    [E, N, K//32]`` (fp16). Returns ``[R, N]`` bf16. ``part`` may be a
    preallocated ``[SK*R, N]`` fp32 buffer (pass it under capture).

    Use it for single-token (decode) projections on int4-b32 packed weights (``packed [E, N,
    K//2]`` uint8 + ``scales [E, N, K//32]`` fp16 from ``pack_int4_b32`` or
    ``gptq_pack_int4_b32``) with ``quant_x_rows`` activations. Returns ``[R, N]`` bf16.
    Needs a CUDA GPU (sm_80+) and Triton. See ``docs/solutions/int4-decode-gemv.md``.
    """
    R = eids.numel()
    bn, wp, sk, ku = _plan(N, K)
    if part is None:
        part = torch.empty(sk * R, N, dtype=torch.float32, device=xq.device)
    _gemv_int4_b32[(triton.cdiv(N, bn), R, sk)](
        xq, xs, packed, scales, eids, part,
        N, K=K, R=R, BLOCK_N=bn, SK=sk, KU=ku, num_warps=wp)
    return reduce_partials(part, sk, R, N)


# ------------------------------------------------- grouped M-tile GEMM --
@triton.jit
def _gemm_int4_b32_grouped(aq_ptr, as_ptr, w_ptr, ws_ptr,
                           row0_ptr, rows_ptr, grp_ptr, out_ptr,
                           N, K: tl.constexpr,
                           BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    """M-tile grouped GEMM over PREBUILT device tiles (the NF4 captured
    path's tile contract: ``build_group_tiles_device``). One program
    computes ``rows[g] x BLOCK_N`` outputs of expert ``grp[g]``.

    Same arithmetic as the decode GEMV: int8 activations against
    arithmetically-unpacked int4 nibbles, exact integer accumulation,
    one fp32 scale product per (row, k-block) -- but the integer MAC
    runs as ``tl.dot`` int8 MMA. The byte interleave is handled the
    GEMV's way: even-k activations dot the LOW nibbles, odd-k the HIGH,
    two K=16 dots per 32-block, so no strided reshuffle of the weight
    tile is ever built.

    Zero-row tiles exit before the K loop (the shipped zero-tile
    lesson: padding tiles at a static grid must cost a launch, not a
    weight read)."""
    g = tl.program_id(0)
    pid_n = tl.program_id(1)
    rows = tl.load(rows_ptr + g)
    if rows == 0:
        return
    row0 = tl.load(row0_ptr + g).to(tl.int64)
    eid = tl.load(grp_ptr + g).to(tl.int64)
    offs_m = tl.arange(0, BLOCK_M)
    m_mask = offs_m < rows
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    n_mask = offs_n < N
    KB: tl.constexpr = K // 32
    pair = tl.arange(0, 16)
    o32 = tl.arange(0, 32)
    wbase = w_ptr + eid * N * (K // 2)
    sbase = ws_ptr + eid * N * KB
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for kb in range(0, KB):
        # activations in NATURAL k order; the weight tile is rebuilt to
        # match via tl.interleave (even k = LOW nibble), because int8
        # tl.dot needs K >= 32 -- two K=16 nibble-lane dots refuse to
        # compile (min_dot_size), found on the first GPU parity run.
        a = tl.load(aq_ptr + (row0 + offs_m)[:, None] * K + kb * 32
                    + o32[None, :], mask=m_mask[:, None], other=0)
        asv = tl.load(as_ptr + (row0 + offs_m) * KB + kb,
                      mask=m_mask, other=0.0)
        wb = tl.load(wbase + offs_n[:, None] * (K // 2) + kb * 16
                     + pair[None, :],
                     mask=n_mask[:, None], other=0).to(tl.int32)
        lo = ((wb & 0xF) - 8).to(tl.int8)
        hi = (((wb >> 4) & 0xF) - 8).to(tl.int8)
        w32 = tl.interleave(lo, hi)              # [BLOCK_N, 32], k-order
        d = tl.dot(a, tl.trans(w32), out_dtype=tl.int32)
        ws = tl.load(sbase + offs_n * KB + kb, mask=n_mask,
                     other=0.0).to(tl.float32)
        acc += d.to(tl.float32) * (asv[:, None] * ws[None, :])
    ooff = (row0 + offs_m)[:, None] * N + offs_n[None, :]
    tl.store(out_ptr + ooff, acc.to(tl.bfloat16),
             mask=m_mask[:, None] & n_mask[None, :])


def gemm_int4_b32_grouped_captured(aq_sorted, as_sorted, packed, scales,
                                   t_row0, t_rows, t_group,
                                   block_m: int = 16,
                                   block_n: int = 64, warps: int = 8):
    """Grouped int4-b32 GEMM against prebuilt device tiles.

    ``aq_sorted [R, K] int8`` / ``as_sorted [R, K//32] fp32`` are the
    quantised activations gathered into expert-major order (the tile
    builder's ``order``); ``t_group`` values are LOCAL indices into
    ``packed [E, N, K//2]`` / ``scales [E, N, K//32]``. Every launch
    parameter is static and every input is a device tensor, so the call
    is legal inside CUDA-graph capture; the only allocation is ``out``
    (the certified private-pool pattern). Returns ``[R, N]`` bf16 in the
    SORTED row order -- the caller scatters back by the inverse of
    ``order``, exactly as on the NF4 captured path.

    Default config bn64/w8: the graph-metric sweep's winner on BOTH
    census cells (gate_up 208.28 vs 216.10 us at bn128/w4; down 45.06
    vs 56.66 -- receipts INT4B16/P1). The first composed run shipped
    the un-swept bn128/w4 default and paid ~0.9 ms/step for it: a
    sweep that does not update the DEFAULT has not finished."""
    R, K = aq_sorted.shape
    E, N, _kh = packed.shape
    out = torch.empty(R, N, dtype=torch.bfloat16, device=aq_sorted.device)
    _gemm_int4_b32_grouped[(t_row0.numel(), triton.cdiv(N, block_n))](
        aq_sorted, as_sorted, packed, scales,
        t_row0, t_rows, t_group, out,
        N, K=K, BLOCK_M=block_m, BLOCK_N=block_n, num_warps=warps)
    return out


# ------------------------------------------------ tail-fusion kernels --
@triton.jit
def _tile_table_r1(eids_ptr, row0_ptr, rows_ptr, grp_ptr, order_ptr,
                   counts_ptr, R: tl.constexpr, RB: tl.constexpr,
                   E: tl.constexpr, EB: tl.constexpr, TB: tl.constexpr,
                   BM: tl.constexpr, MAXT: tl.constexpr):
    """ONE launch builds the whole expert-major tile table for decode
    shapes: counts, exclusive row offsets, a STABLE counting-sort order,
    and the (row0, rows, grp) tile slots -- the work the chained
    argsort/cumsum/searchsorted/index_select builder spread over ~10
    launches per layer (48 radix sorts per B=16 step in the census).

    Stability is by construction: a row's rank within its expert is the
    count of EARLIER rows with the same expert id, so ties keep input
    order exactly as a stable argsort does. Decode-only by contract
    (R <= a few hundred): the O(R^2) rank compare is one small block
    here and would not scale to prefill chunks -- the caller keeps the
    chained builder for those, where launches amortize."""
    r = tl.arange(0, RB)
    rmask = r < R
    e = tl.load(eids_ptr + r, mask=rmask, other=E).to(tl.int32)
    # per-expert counts (sentinel E lands in no bin)
    ee = tl.arange(0, EB)
    emask = ee < E
    hits = (e[None, :] == ee[:, None]) & rmask[None, :]
    counts = tl.sum(hits.to(tl.int32), axis=1)          # [EB]
    tl.store(counts_ptr + ee, counts.to(tl.int64), mask=emask)
    row_off = tl.cumsum(counts, axis=0) - counts         # exclusive
    # stable rank: earlier rows with the same expert id
    same = (e[:, None] == e[None, :]) & (r[None, :] < r[:, None])
    rank = tl.sum(same.to(tl.int32), axis=1)             # [RB]
    dst = tl.sum(tl.where(hits, row_off[:, None], 0), axis=0) + rank
    tl.store(order_ptr + dst, r.to(tl.int64), mask=rmask)
    # tile slots: expert e owns tiles [tile_off[e], tile_off[e]+tpe[e])
    tpe = (counts + BM - 1) // BM
    tile_off = tl.cumsum(tpe, axis=0) - tpe
    ti = tl.arange(0, MAXT)
    live = (ti[None, :] < tpe[:, None]) & emask[:, None]     # [EB, MAXT]
    slot = tile_off[:, None] + ti[None, :]
    slot = tl.where(live, slot, 0)        # dead lanes: address clamped,
    rows_v = tl.minimum(counts[:, None] - ti[None, :] * BM, BM)
    row0_v = row_off[:, None] + ti[None, :] * BM
    grp_v = tl.broadcast_to(ee[:, None], (EB, MAXT))
    # ... and the store MASKED off entirely: duplicate-address stores
    # have undefined lane order, so "park on a slot and write zeros"
    # would race a live lane's write. The caller pre-zeroes the static
    # TB-slot table; padding slots simply stay untouched.
    lf = tl.reshape(live, (EB * MAXT,))
    sf = tl.reshape(slot, (EB * MAXT,))
    tl.store(rows_ptr + sf, tl.reshape(rows_v.to(tl.int32),
                                       (EB * MAXT,)), mask=lf)
    tl.store(row0_ptr + sf, tl.reshape(row0_v.to(tl.int32),
                                       (EB * MAXT,)), mask=lf)
    tl.store(grp_ptr + sf, tl.reshape(grp_v.to(tl.int32),
                                      (EB * MAXT,)), mask=lf)


def build_group_tiles_fused(expert_ids, n_experts: int, block_m: int,
                            tiles_budget: int | None = None):
    """Drop-in for ``nf4_grouped.build_group_tiles_device`` on DECODE
    shapes (R <= 256): same five outputs, same dtypes, same tile-slot
    semantics (padding slots rows=0), one kernel launch. Raises on
    shapes outside its contract -- the caller falls back to the chained
    builder there rather than getting a silently different table."""
    r = expert_ids.numel()
    if r > 256:
        raise ValueError(f"fused tile builder is decode-only (R <= 256); "
                         f"got R={r} -- use the chained builder")
    if r == 0:
        # empty routing: no launch (tl.arange(0, 0) is invalid) -- the
        # zeroed table, empty order, and zero counts ARE the answer,
        # matching the chained builder (review finding, round 1)
        dev = expert_ids.device
        tb = (n_experts if tiles_budget is None else tiles_budget)
        return (torch.zeros(tb, dtype=torch.int32, device=dev),
                torch.zeros(tb, dtype=torch.int32, device=dev),
                torch.zeros(tb, dtype=torch.int32, device=dev),
                torch.empty(0, dtype=torch.int64, device=dev),
                torch.zeros(n_experts, dtype=torch.int64, device=dev))
    if tiles_budget is None:
        tiles_budget = -(-r // block_m) + n_experts
    dev = expert_ids.device
    row0 = torch.zeros(tiles_budget, dtype=torch.int32, device=dev)
    rows = torch.zeros(tiles_budget, dtype=torch.int32, device=dev)
    grp = torch.zeros(tiles_budget, dtype=torch.int32, device=dev)
    order = torch.empty(r, dtype=torch.int64, device=dev)
    counts = torch.empty(n_experts, dtype=torch.int64, device=dev)
    maxt = -(-r // block_m) + 1
    _tile_table_r1[(1,)](
        expert_ids.to(torch.int32), row0, rows, grp, order, counts,
        R=r, RB=triton.next_power_of_2(r), E=n_experts,
        EB=triton.next_power_of_2(n_experts), TB=tiles_budget,
        BM=block_m, MAXT=triton.next_power_of_2(maxt))
    return row0, rows, grp, order, counts


@triton.jit
def _quant_x_rows_gathered(x_ptr, ord_ptr, xq_ptr, xs_ptr,
                           K: tl.constexpr):
    """``_quant_x_rows`` with the expert-major GATHER folded in: output
    row ``r`` quantises input row ``order[r]``. Kills the standalone
    [R, K] index_select the serving loop paid per layer (census: 48
    calls / 0.46 ms per B=16 step)."""
    r = tl.program_id(0)
    kb = tl.program_id(1)
    src = tl.load(ord_ptr + r).to(tl.int64)
    o32 = tl.arange(0, 32)
    x = tl.load(x_ptr + src * K + kb * 32 + o32).to(tl.float32)
    s = tl.max(tl.abs(x)) / 127.0 + 1e-12
    q = tl.floor(x / s + 0.5)
    q = tl.minimum(tl.maximum(q, -127.0), 127.0)
    tl.store(xq_ptr + r * K + kb * 32 + o32, q.to(tl.int8))
    tl.store(xs_ptr + r * (K // 32) + kb, s)


def quant_x_rows_gathered(x: torch.Tensor, order: torch.Tensor):
    """``(x [R, K], order [R]) -> (xq [R, K] int8, xs [R, K//32] fp32)``
    with ``xq[r] = quantise(x[order[r]])`` -- bit-identical to
    ``quant_x_rows(x.index_select(0, order))``."""
    R, K = x.shape
    xq = torch.empty(R, K, dtype=torch.int8, device=x.device)
    xs = torch.empty(R, K // BLOCK, dtype=torch.float32, device=x.device)
    _quant_x_rows_gathered[(R, K // BLOCK)](
        x.contiguous(), order, xq, xs, K=K)
    return xq, xs


@triton.jit
def _swiglu_rows(gu_ptr, h_ptr, I: tl.constexpr, BS: tl.constexpr):
    """h = silu(gate) * up over a [R, 2I] gate-block-then-up-block
    matrix, one kernel instead of the chunk/silu/mul chain."""
    r = tl.program_id(0)
    c = tl.program_id(1)
    offs = c * BS + tl.arange(0, BS)
    m = offs < I
    g = tl.load(gu_ptr + r * (2 * I) + offs, mask=m,
                other=0.0).to(tl.float32)
    u = tl.load(gu_ptr + r * (2 * I) + I + offs, mask=m,
                other=0.0).to(tl.float32)
    h = (g * tl.sigmoid(g)) * u
    tl.store(h_ptr + r * I + offs, h.to(tl.bfloat16), mask=m)


def swiglu_rows(gu: torch.Tensor):
    """``gu [R, 2I]`` (gate block then up block) -> ``h [R, I]`` bf16."""
    R, twoI = gu.shape
    inter = twoI // 2
    h = torch.empty(R, inter, dtype=torch.bfloat16, device=gu.device)
    bs = min(1024, triton.next_power_of_2(inter))
    _swiglu_rows[(R, triton.cdiv(inter, bs))](
        gu.contiguous(), h, I=inter, BS=bs)
    return h


# ------------------------------------------ top-k weighted combine --
@triton.jit
def _combine_rows(dn_ptr, w_ptr, out_ptr, K: tl.constexpr, H,
                  BLOCK: tl.constexpr):
    """``out[t, :] = bf16(sum_j fp32(dn[t*K + j, :]) * w[t*K + j])`` --
    the MoE combine (weight, sum over the top-k, cast) in one launch. The
    torch chain it replaces was four dispatches per layer (to_copy,
    mul, sum, to_copy) and two kernels; the Qwen3 B=1 op census put
    them at the top of the collapsed forward's glue."""
    t = tl.program_id(0)
    pid = tl.program_id(1)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    m = offs < H
    acc = tl.zeros((BLOCK,), dtype=tl.float32)
    for j in tl.static_range(K):
        w = tl.load(w_ptr + t * K + j).to(tl.float32)
        acc += tl.load(dn_ptr + (t * K + j) * H + offs, mask=m,
                       other=0.0).to(tl.float32) * w
    tl.store(out_ptr + t * H + offs, acc.to(tl.bfloat16), mask=m)


def combine_rows(dn: torch.Tensor, w: torch.Tensor, k: int):
    """``dn [T*k, H]`` (bf16 expert outputs, token-major, k slots per
    token) and ``w [T*k]`` (routing weights) -> ``[T, H]`` bf16, one
    launch. Summation is fp32 in slot order, as the torch chain's is."""
    TK, H = dn.shape
    T = TK // k
    out = torch.empty(T, H, dtype=torch.bfloat16, device=dn.device)
    block = min(1024, triton.next_power_of_2(H))
    _combine_rows[(T, triton.cdiv(H, block))](
        dn.contiguous(), w.contiguous(), out, K=k, H=H, BLOCK=block,
        num_warps=4)
    return out


# --------------------------------------------------- fused T=1 RMSNorm --
@triton.jit
def _rmsnorm_rows(x_ptr, w_ptr, out_ptr, R, H: tl.constexpr,
                  HB: tl.constexpr, EPS: tl.constexpr):
    """One launch per RMSNorm site: the fp32 mean-square reduce, the
    rsqrt scale, the weight multiply, and the cast back -- the chain
    torch runs as 3-4 kernels per call at decode shapes. Row-parallel
    (grid (R,)) so the same kernel serves the [1, H] layer norms and the
    [heads, head_dim] q/k norms. The weight read is ~4 KB per call, so
    the single-CTA bandwidth trap that refused the fused router (P10)
    does not transfer."""
    r = tl.program_id(0)
    offs = tl.arange(0, HB)
    m = offs < H
    x = tl.load(x_ptr + r * H + offs, mask=m, other=0.0).to(tl.float32)
    ms = tl.sum(x * x, axis=0) / H
    inv = 1.0 / tl.sqrt(ms + EPS)
    w = tl.load(w_ptr + offs, mask=m, other=0.0).to(tl.float32)
    y = x * inv * w
    tl.store(out_ptr + r * H + offs, y.to(tl.bfloat16), mask=m)


def rmsnorm_rows(x: torch.Tensor, weight: torch.Tensor, eps: float):
    """``x [..., H]`` -> RMSNorm'd bf16, upstream semantics: fp32
    mean-square over the LAST axis, ``x * rsqrt(ms + eps) * weight``,
    cast back. Rows are all leading axes flattened."""
    H = x.shape[-1]
    xf = x.reshape(-1, H)
    out = torch.empty_like(xf, dtype=torch.bfloat16)
    _rmsnorm_rows[(xf.shape[0],)](
        xf.contiguous(), weight.contiguous(), out, xf.shape[0],
        H=H, HB=triton.next_power_of_2(H), EPS=eps, num_warps=8)
    return out.reshape(x.shape)


# ----------------------------------------- fused residual + RMSNorm --
@triton.jit
def _rmsnorm_resid_rows(x_ptr, res_ptr, w_ptr, out_ptr, nres_ptr, scale,
                        H: tl.constexpr, HB: tl.constexpr, EPS: tl.constexpr,
                        SCALED: tl.constexpr):
    """The decoder layer's ``resid = resid + x; h = rmsnorm(resid)``
    pair as ONE launch: torch runs it as an elementwise add plus the
    3-4 kernel norm chain, twice per layer. The add rounds once to
    bf16 exactly as the upstream bf16 ``+`` does (both operands are
    exact in fp32, so fp32-add-then-round is the same single
    rounding), then the norm reads that rounded value -- upstream
    semantics, not merely close. Row-parallel; ~4 KB weight pull.

    ``SCALED``: the GraniteMoe body is ``resid + x * multiplier``. The
    bf16 product rounds to bf16 BEFORE the add upstream (a bf16 tensor
    times a Python float is one fp32 multiply and one rounding), so the
    scaled path reproduces that rounding rather than folding the scale
    into the fp32 sum -- two roundings, as upstream, not one."""
    r = tl.program_id(0)
    offs = tl.arange(0, HB)
    m = offs < H
    x = tl.load(x_ptr + r * H + offs, mask=m, other=0.0).to(tl.float32)
    if SCALED:
        x = (x * scale).to(tl.bfloat16).to(tl.float32)
    s = tl.load(res_ptr + r * H + offs, mask=m, other=0.0).to(tl.float32) + x
    nr = s.to(tl.bfloat16)
    tl.store(nres_ptr + r * H + offs, nr, mask=m)
    sf = nr.to(tl.float32)
    ms = tl.sum(sf * sf, axis=0) / H
    inv = 1.0 / tl.sqrt(ms + EPS)
    w = tl.load(w_ptr + offs, mask=m, other=0.0).to(tl.float32)
    tl.store(out_ptr + r * H + offs, (sf * inv * w).to(tl.bfloat16), mask=m)


def rmsnorm_resid_rows(x: torch.Tensor, resid: torch.Tensor,
                       weight: torch.Tensor, eps: float, scale: float = 1.0):
    """``(resid + x * scale)`` then RMSNorm, one launch. Returns
    ``(normed, new_resid)`` both bf16, shapes of ``x``. ``scale`` is the
    residual multiplier of bodies like GraniteMoe's; at its default of
    1.0 the sum is bitwise the upstream bf16 add, and for any other
    value the product rounds to bf16 first, as upstream's does."""
    H = x.shape[-1]
    xf = x.reshape(-1, H)
    rf = resid.reshape(-1, H)
    out = torch.empty_like(xf, dtype=torch.bfloat16)
    nres = torch.empty_like(xf, dtype=torch.bfloat16)
    scale = float(scale)
    _rmsnorm_resid_rows[(xf.shape[0],)](
        xf.contiguous(), rf.contiguous(), weight.contiguous(), out, nres,
        scale, H=H, HB=triton.next_power_of_2(H), EPS=eps,
        SCALED=(scale != 1.0), num_warps=8)
    return out.reshape(x.shape), nres.reshape(x.shape)


# --------------------------------------------- scaled residual add --
@triton.jit
def _scaled_resid_add_rows(x_ptr, res_ptr, out_ptr, scale, H: tl.constexpr,
                           HB: tl.constexpr):
    """``resid + x * scale`` as ONE launch with upstream's two bf16
    roundings (product, then sum). torch runs the multiply and the add
    as two kernels; a single ``torch.add(alpha=)`` rounds once and is
    therefore not the upstream value. Used for the layer tail, where no
    norm follows within the layer."""
    r = tl.program_id(0)
    offs = tl.arange(0, HB)
    m = offs < H
    x = tl.load(x_ptr + r * H + offs, mask=m, other=0.0).to(tl.float32)
    xs = (x * scale).to(tl.bfloat16).to(tl.float32)
    s = tl.load(res_ptr + r * H + offs, mask=m, other=0.0).to(tl.float32) + xs
    tl.store(out_ptr + r * H + offs, s.to(tl.bfloat16), mask=m)


def scaled_resid_add_rows(x: torch.Tensor, resid: torch.Tensor, scale: float):
    """``resid + x * scale`` in bf16, one launch, upstream rounding
    (the product rounds to bf16 before the add). Shape of ``x``."""
    H = x.shape[-1]
    xf = x.reshape(-1, H)
    rf = resid.reshape(-1, H)
    out = torch.empty_like(xf, dtype=torch.bfloat16)
    _scaled_resid_add_rows[(xf.shape[0],)](
        xf.contiguous(), rf.contiguous(), out, float(scale),
        H=H, HB=triton.next_power_of_2(H), num_warps=8)
    return out.reshape(x.shape)


# ------------------------------------ fused q/k RMSNorm + rotary ------
@triton.jit
def _rope_norm_heads(x_ptr, w_ptr, cos_ptr, sin_ptr, out_ptr,
                     HEADS: tl.constexpr, D: tl.constexpr,
                     DB: tl.constexpr, EPS: tl.constexpr):
    """Per-head RMSNorm followed by rotate-half rotary, one launch for
    all heads of one projection: replaces the norm launch plus the
    ~6-kernel ``apply_rotary_pos_emb`` chain (cat, neg, two muls, add,
    dtype glue). Grid (rows, heads); each program pulls one [D] head
    vector plus the shared [D] weight and this row's [D] cos/sin --
    ~2 KB, occupancy-safe. rotate_half convention: halves split at
    D/2, ``y = xn * cos + [-xn2, xn1] * sin`` where xn is the NORMED
    vector (norm precedes rotary upstream), fp32 math, bf16 store."""
    r = tl.program_id(0)
    h = tl.program_id(1)
    offs = tl.arange(0, DB)
    m = offs < D
    base = (r * HEADS + h) * D
    x = tl.load(x_ptr + base + offs, mask=m, other=0.0).to(tl.float32)
    ms = tl.sum(x * x, axis=0) / D
    inv = 1.0 / tl.sqrt(ms + EPS)
    w = tl.load(w_ptr + offs, mask=m, other=0.0).to(tl.float32)
    xn = x * inv * w
    half = D // 2
    lo = offs < half
    pidx = tl.where(lo, offs + half, offs - half)
    xp = tl.load(x_ptr + base + pidx, mask=m, other=0.0).to(tl.float32)
    wp = tl.load(w_ptr + pidx, mask=m, other=0.0).to(tl.float32)
    pn = xp * inv * wp
    rot = tl.where(lo, -pn, pn)
    cos = tl.load(cos_ptr + r * D + offs, mask=m, other=0.0).to(tl.float32)
    sin = tl.load(sin_ptr + r * D + offs, mask=m, other=0.0).to(tl.float32)
    tl.store(out_ptr + base + offs, (xn * cos + rot * sin).to(tl.bfloat16),
             mask=m)


def rope_norm_heads(x: torch.Tensor, weight: torch.Tensor,
                    cos: torch.Tensor, sin: torch.Tensor, eps: float):
    """``x [R, HEADS, D]`` -> per-head RMSNorm (``weight [D]``) then
    rotate-half rotary with this row's ``cos/sin [R, D]``; bf16 out,
    same shape. The norm-then-rotate order and the D/2 half split
    mirror the upstream attention forward exactly."""
    R, HEADS, D = x.shape
    out = torch.empty(R, HEADS, D, dtype=torch.bfloat16, device=x.device)
    _rope_norm_heads[(R, HEADS)](
        x.contiguous(), weight.contiguous(), cos.contiguous(),
        sin.contiguous(), out, HEADS=HEADS, D=D,
        DB=triton.next_power_of_2(D), EPS=eps, num_warps=4)
    return out


# ------------------------------------------ rotary only (no head norm) --
@triton.jit
def _rope_heads(x_ptr, cos_ptr, sin_ptr, out_ptr,
                HEADS: tl.constexpr, D: tl.constexpr, DB: tl.constexpr):
    """Rotate-half rotary for all heads of one projection in one launch,
    for attention WITHOUT a per-head norm (GraniteMoe, Mixtral): the same
    ``apply_rotary_pos_emb`` chain the norm+rotary fold replaces, minus
    the norm. fp32 math, bf16 store; halves split at D/2."""
    r = tl.program_id(0)
    h = tl.program_id(1)
    offs = tl.arange(0, DB)
    m = offs < D
    base = (r * HEADS + h) * D
    x = tl.load(x_ptr + base + offs, mask=m, other=0.0).to(tl.float32)
    half = D // 2
    lo = offs < half
    pidx = tl.where(lo, offs + half, offs - half)
    xp = tl.load(x_ptr + base + pidx, mask=m, other=0.0).to(tl.float32)
    rot = tl.where(lo, -xp, xp)
    cos = tl.load(cos_ptr + r * D + offs, mask=m, other=0.0).to(tl.float32)
    sin = tl.load(sin_ptr + r * D + offs, mask=m, other=0.0).to(tl.float32)
    tl.store(out_ptr + base + offs, (x * cos + rot * sin).to(tl.bfloat16),
             mask=m)


def rope_heads(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor):
    """``x [R, HEADS, D]`` -> rotate-half rotary with this row's
    ``cos/sin [R, D]``; bf16 out, same shape. No norm: the input is the
    projection output as upstream's ``apply_rotary_pos_emb`` sees it."""
    R, HEADS, D = x.shape
    out = torch.empty(R, HEADS, D, dtype=torch.bfloat16, device=x.device)
    _rope_heads[(R, HEADS)](
        x.contiguous(), cos.contiguous(), sin.contiguous(), out,
        HEADS=HEADS, D=D, DB=triton.next_power_of_2(D), num_warps=4)
    return out


# ------------------------------------------- fused router epilogue (T=1) --
@triton.jit
def _router_epilogue(logit_ptr, bias_ptr, prob_ptr, wout_ptr, iout_ptr,
                     E: tl.constexpr, EB: tl.constexpr, K: tl.constexpr,
                     KB: tl.constexpr, NORM: tl.constexpr,
                     HAS_BIAS: tl.constexpr, SELECT_ON_LOGITS: tl.constexpr):
    """softmax over all experts, top-K select, optional renormalise --
    the five-launch chain torch runs per layer (softmax, gatherTopK, its
    bitonic sort, the sum, the divide) as one launch on ONE row.

    This is the epilogue only: the router's own GEMM stays where it is.
    That distinction is the whole reason this fusion is licensed where
    the fused router GEMM was refused -- a program here pulls E floats
    (512 B at E=128), not the router weight matrix, so the single-CTA
    bandwidth trap does not apply and what remains is launch count.

    Selection is by iterated max with ties going to the LOWER expert
    index, matching a stable descending sort. ``K`` need not be a power
    of two: the register vectors are padded to ``KB`` and masked, since
    ``tl.arange`` only spans powers of two and a model whose top_k is
    not one would otherwise fail at launch."""
    r = tl.program_id(0)
    offs = tl.arange(0, EB)
    m = offs < E
    x = tl.load(logit_ptr + r * E + offs, mask=m,
                other=-float("inf")).to(tl.float32)
    if HAS_BIAS:
        x = x + tl.load(bias_ptr + offs, mask=m, other=0.0).to(tl.float32)
    if SELECT_ON_LOGITS:
        # gpt-oss / GraniteMoe: the module returns the (biased) logits as
        # its first output, selects top-k ON THE LOGITS, and softmaxes
        # over the k it selected (below). Masked and already-selected
        # lanes sit at -inf so they can never win a later round.
        tl.store(prob_ptr + r * E + offs, x, mask=m)
        sel = tl.where(m, x, -float("inf"))
    else:
        ex = tl.exp(x - tl.max(x, axis=0))
        ex = tl.where(m, ex, 0.0)
        p = ex / tl.sum(ex, axis=0)
        tl.store(prob_ptr + r * E + offs, p, mask=m)
        # -1.0 is below every softmax probability, so masked and already
        # selected lanes can never win a later round
        sel = tl.where(m, p, -1.0)
    kk = tl.arange(0, KB)
    kmask = kk < K
    vals = tl.zeros((KB,), dtype=tl.float32)
    idxs = tl.zeros((KB,), dtype=tl.int32)
    for j in range(K):
        v = tl.max(sel, axis=0)
        i = tl.argmax(sel, axis=0).to(tl.int32)
        vals = tl.where(kk == j, v, vals)
        idxs = tl.where(kk == j, i, idxs)
        if SELECT_ON_LOGITS:
            sel = tl.where(offs == i, -float("inf"), sel)
        else:
            sel = tl.where(offs == i, -1.0, sel)
    if SELECT_ON_LOGITS:
        # softmax over the k selected logits (fp32), padded lanes excluded
        mx = tl.max(tl.where(kmask, vals, -float("inf")), axis=0)
        ev = tl.where(kmask, tl.exp(vals - mx), 0.0)
        vals = ev / tl.sum(ev, axis=0)
    elif NORM:
        vals = vals / tl.sum(tl.where(kmask, vals, 0.0), axis=0)
    tl.store(wout_ptr + r * K + kk, vals, mask=kmask)
    tl.store(iout_ptr + r * K + kk, idxs.to(tl.int64), mask=kmask)


def router_epilogue(logits: torch.Tensor, k: int, norm: bool, *,
                    select_on_logits: bool = False,
                    bias: torch.Tensor | None = None):
    """``logits [R, E]`` -> ``(first [R, E] fp32, weights [R, k] fp32,
    indices [R, k] int64)``.

    Default (``select_on_logits=False``): the Qwen3-MoE / OLMoE /
    Mixtral epilogue -- fp32 softmax over ALL experts, then top-k, then
    the optional renormalisation; ``first`` is the probabilities.

    ``select_on_logits=True``: the gpt-oss / GraniteMoe epilogue -- top-k
    ON THE LOGITS (plus ``bias`` when the router carries one), then a
    softmax over the k selected logits; ``first`` is the (biased) logits,
    which is what those modules return. ``norm`` is ignored in this mode
    (the k-softmax already sums to one)."""
    R, E = logits.shape
    first = torch.empty(R, E, dtype=torch.float32, device=logits.device)
    w = torch.empty(R, k, dtype=torch.float32, device=logits.device)
    idx = torch.empty(R, k, dtype=torch.int64, device=logits.device)
    has_bias = bias is not None
    if has_bias and tuple(bias.shape) != (E,):
        raise ValueError(f"router bias must be [E={E}], got {tuple(bias.shape)}")
    b = bias.contiguous().to(torch.float32) if has_bias else first  # inert ptr when unused
    _router_epilogue[(R,)](
        logits.contiguous(), b, first, w, idx, E=E,
        EB=triton.next_power_of_2(E), K=k, KB=triton.next_power_of_2(k),
        NORM=bool(norm), HAS_BIAS=has_bias,
        SELECT_ON_LOGITS=bool(select_on_logits), num_warps=4)
    return first, w, idx
